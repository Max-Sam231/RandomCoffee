
import TopicsList from './components/TopicsList';

function TopicsPage() {
  return (
    <>
      <TopicsList />
    </>
  );
}

export default TopicsPage;
